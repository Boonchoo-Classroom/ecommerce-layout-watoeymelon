package scisrc.mobiledev.ecommercelayout.ui

data class PromotionModel(
    val title: String,
    val description: String,
    val imageRes: Int
)
